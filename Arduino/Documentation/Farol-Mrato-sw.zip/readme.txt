*******************************************************************************
Name: 		MR_BEACON.HEX
Project:	Variable Clock Generator (Micro-Rato IR Beacon)
Author:     Bernardo Cunha
Date:       2004-03-10
*******************************************************************************

Description:

This program is used to generate a square wave of programmable frequency. 
The signal is outputed in the pin 0 of PORT A. PORT A pin 2 will present 
a similar signal with a phase shift of 180 degrees.

The period of the signal is programmed to be 25 microseconds (40Khz) 
with a duty cycle that can vary with a resolution of 1 microsecond.
Duty cycle is given by the following formula:

		Dc = (12 + (1 + PBv[4Lsbits]) * 4))*.8 (%)
			or
		PBv[4Lsbits] = 1 + (((Dc * 1.25) - 12) / 3)
			
		with Pr -> Period
		PBv 	-> Port B binary value

Port B bits [6..4] can be used to define modulating frequency.
Valid values are:
			0	 2.5 KHz
			1	 2.0 KHz	
			2	 1.25 KHz
			3	 1.0 KHz
			4	 800 Hz
			5	 625 Hz
			6	 500 Hz
			7	 400 Hz

PORT A pin 1 can be used to drive a led that will blink at a low frequency 
rate proportional to the square wave frequency. The minimum allowable 
PBv value for which the led still works is 4.
*******************************************************************************
